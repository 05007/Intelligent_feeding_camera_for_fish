/***************************************************************
 文件名 : uart.hpp
 版本 : v1.0.0
 作者 : 郭辰磊
 单位 : 中国农业大学-国家数字渔业创新中心-数字养殖网箱项目
 描述 : 控制SCA200芯片的UART串口连接
 其他 : 无
 日志 : 初版v1.0.0 2023/3/10 郭辰磊创建
 ***************************************************************/
#ifndef  _USART_HPP
#define  _USART_HPP
#include<sys/mman.h>
#include<stdio.h>      /*标准输入输出定义*/
#include<stdlib.h>     /*标准函数库定义*/
#include<unistd.h>     /*Unix 标准函数定义*/
#include<sys/types.h>
#include<sys/stat.h>
#include<fcntl.h>      /*文件控制定义*/
#include<termios.h>    /*PPSIX 终端控制定义*/
#include<errno.h>      /*错误号定义*/
#include<string.h>
#include<iostream>      /*C++IO*/
#include<fstream>
using namespace std;
typedef unsigned char Rcode;
#define DATA_BUFFER_SIZE 50 //数据缓冲池大小

int UART_Set(int fd,int speed,int flow_ctrl,int databits,int stopbits,int parity);
int UART_Recv(int fd, Rcode* rcv_buf,int data_len);
int UART_Send(int fd, Rcode* send_buf,int data_len);
#endif
