#include "uart.hpp"
int main(){
    int uart_fd=open("/dev/ttyS2", O_RDWR | O_NOCTTY);
    UART_Set(uart_fd,19200,0,8,1,'E');
    if (uart_fd < 0) cout<<"uart open error!"<<endl;
    cout<<"test_uart start"<<endl;
    while(1){   //接受数据后原样输出
        sleep(3);
        Rcode rcv_buff[DATA_BUFFER_SIZE];
		int len = UART_Recv(uart_fd,rcv_buff, DATA_BUFFER_SIZE);
		if(len > 0)
			UART_Send(uart_fd,rcv_buff,len);
    }
    return 0;
}
